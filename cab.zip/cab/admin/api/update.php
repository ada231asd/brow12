<?php
session_start();
require_once 'db.php';

function handleUpdate($pdo, $table, $role_id) {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        die(json_encode(['error' => 'Метод не поддерживается']));
    }

    // Исправляем формат прав: edit_table вместо edit_$table
    $hasPermission = checkRolePermission($role_id, "edit_" . strtolower($table));
    if (!$hasPermission) {
        die(json_encode(['error' => "Недостаточно прав для edit_" . strtolower($table) . ", role_id: $role_id"]));
    }

    $id = $_GET['id'] ?? null;
    if (!$id) {
        die(json_encode(['error' => 'Не указан ID']));
    }

    try {
        // Проверяем, существует ли запись
        $idColumn = $table === 'Users' ? 'user_id' : ($table === 'Orders' ? 'order_id' : ($table === 'Reviews' ? 'review_id' : strtolower($table) . '_id'));
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM $table WHERE $idColumn = ?");
        $stmt->execute([$id]);
        if ($stmt->fetchColumn() == 0) {
            die(json_encode(['error' => 'Запись не найдена']));
        }

        $data = [];
        foreach ($_POST as $key => $value) {
            if ($key === 'role_name') continue; // Пропускаем role_name, используем role_id
            $data[$key] = $value;
        }

        // Обработка загрузки файла
        if (isset($_FILES['image_url']) && $_FILES['image_url']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (!in_array($_FILES['image_url']['type'], $allowedTypes)) {
                die(json_encode(['error' => 'Недопустимый тип файла. Допустимы: JPEG, PNG, GIF']));
            }

            $uploadDir = 'full_image/' . strtolower($table) . '/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            $fileName = uniqid() . '-' . basename($_FILES['image_url']['name']);
            $filePath = $uploadDir . $fileName;
            if (move_uploaded_file($_FILES['image_url']['tmp_name'], $filePath)) {
                $data['image_url'] = str_replace('\\', '/', $filePath); // Исправляем слеши
            } else {
                die(json_encode(['error' => 'Ошибка загрузки файла']));
            }
        }

        $setClause = implode(', ', array_map(fn($key) => "$key = ?", array_keys($data)));
        $stmt = $pdo->prepare("UPDATE $table SET $setClause WHERE $idColumn = ?");
        $stmt->execute([...array_values($data), $id]);

        // Логирование действия
        $userData = isset($_SESSION['user']) ? $_SESSION['user'] : null;
        $admin_id = $userData['user_id'] ?? null;
        if ($admin_id) {
            $stmt = $pdo->prepare("INSERT INTO Admin_Logs (admin_id, action, table_name, record_id, action_type) VALUES (?, ?, ?, ?, 'UPDATE')");
            $stmt->execute([$admin_id, "Обновил запись ID $id", $table, $id]);
        }

        echo json_encode(['success' => true]);
    } catch (PDOException $e) {
        echo json_encode(['error' => 'Ошибка обновления: ' . $e->getMessage()]);
    }
}
?>