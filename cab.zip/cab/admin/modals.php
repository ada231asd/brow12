<div id="modal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('modal').style.display='none'">&times;</span>
        <h2 id="modal-title"></h2>
        <form id="modal-form"></form>
    </div>
</div>