<?php
require_once './config/config.php';

if (!hasPermission('get_reviews')) {
    echo "<p>У вас нет доступа к этой странице.</p>";
    return;
}

$stmt = $pdo->query("SELECT r.*, p.name as product_name, u.name as user_name 
                     FROM Reviews r 
                     LEFT JOIN Products p ON r.product_id = p.product_id 
                     LEFT JOIN Users u ON r.user_id = u.user_id");
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Отзывы</h2>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Товар</th>
            <th>Пользователь</th>
            <th>Оценка</th>
            <th>Комментарий</th>
            <th>Статус</th>
            <th>Дата</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($reviews as $review): ?>
            <tr>
                <td><?php echo htmlspecialchars($review['review_id']); ?></td>
                <td><?php echo htmlspecialchars($review['product_name']); ?></td>
                <td><?php echo htmlspecialchars($review['user_name']); ?></td>
                <td><?php echo htmlspecialchars($review['rating']); ?>/5</td>
                <td><?php echo htmlspecialchars($review['comment']); ?></td>
                <td><?php echo htmlspecialchars($review['status']); ?></td>
                <td><?php echo htmlspecialchars($review['created_at']); ?></td>
                <td>
                    <?php if (hasPermission('edit_review')): ?>
                        <a href="../admin/update.php?table=Reviews&id=<?php echo $review['review_id']; ?>">Редактировать</a>
                    <?php endif; ?>
                    <?php if (hasPermission('delete_review')): ?>
                        <a href="../admin/delete.php?table=Reviews&id=<?php echo $review['review_id']; ?>" onclick="return confirm('Вы уверены?')">Удалить</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php if (hasPermission('add_review')): ?>
    <a href="../admin/create.php?table=Reviews" class="btn">Добавить отзыв</a>
<?php endif; ?>