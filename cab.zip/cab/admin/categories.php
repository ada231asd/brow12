<?php
require_once './config/config.php';

if (!hasPermission('get_categories')) {
    echo "<p>У вас нет доступа к этой странице.</p>";
    return;
}

$stmt = $pdo->query("SELECT c1.*, c2.name as parent_name 
                     FROM Categories c1 
                     LEFT JOIN Categories c2 ON c1.parent_category_id = c2.category_id");
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Категории</h2>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Родительская категория</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($categories as $category): ?>
            <tr>
                <td><?php echo htmlspecialchars($category['category_id']); ?></td>
                <td><?php echo htmlspecialchars($category['name']); ?></td>
                <td><?php echo htmlspecialchars($category['parent_name'] ?: 'Нет'); ?></td>
                <td>
                    <?php if (hasPermission('edit_category')): ?>
                        <a href="../admin/update.php?table=Categories&id=<?php echo $category['category_id']; ?>">Редактировать</a>
                    <?php endif; ?>
                    <?php if (hasPermission('delete_category')): ?>
                        <a href="../admin/delete.php?table=Categories&id=<?php echo $category['category_id']; ?>" onclick="return confirm('Вы уверены?')">Удалить</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php if (hasPermission('add_category')): ?>
    <a href="../admin/create.php?table=Categories" class="btn">Добавить категорию</a>
<?php endif; ?>