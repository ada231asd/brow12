<?php
if (!checkRolePermission($userAGC['role_id'], 'get_Product_Characteristics')) {
    echo '<h2>Доступ запрещен</h2>';
    return;
}
?>
<h2>Управление характеристиками</h2>
<button onclick="openCharacteristicModal('create')">Добавить характеристику</button>
<table>
    <thead>
        <tr>
            <th>Название</th>
            <th>Категория</th>
            <th>Тип значения</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody id="Product_Characteristics-table">
        <!-- Данные загружаются через AJAX -->
    </tbody>
</table>